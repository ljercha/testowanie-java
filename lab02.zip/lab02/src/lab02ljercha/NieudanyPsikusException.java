package lab02ljercha;

public class NieudanyPsikusException extends Exception {

}
