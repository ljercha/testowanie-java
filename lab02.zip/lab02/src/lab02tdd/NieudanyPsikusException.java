package lab02tdd;

public class NieudanyPsikusException extends Exception {

}
