package zad01;

public interface ICalculator {
	
	int add(int a, int b);
	int sub(int a, int b);
	int multi(int a, int b);
	int div(int a, int b);
	boolean greater(int a, int b);
}
